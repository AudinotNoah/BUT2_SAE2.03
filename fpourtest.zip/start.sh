#!/bin/bash

# Chemin vers votre jar
CHEMIN="Main"
nohup java  $CHEMIN > /var/log/myweb.log 2>&1 &
echo $! > /var/run/myweb.pid
