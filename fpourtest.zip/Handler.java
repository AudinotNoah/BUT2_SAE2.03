import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.util.Base64;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;

public class Handler implements Runnable {
    private final Socket clientSocket;
    private final Configuration config;

    private final Logger logger;

    public Handler(Socket clientSocket, Configuration config,Logger logger) {
        this.clientSocket = clientSocket;
        this.config = config;
        this.logger = logger;
    }

    @Override
    public void run() {
        try {
            InetAddress clientAddress = clientSocket.getInetAddress();
            String clientIP = clientAddress.getHostAddress();

            if (!checkIP(clientIP)) {
                sendError(clientSocket.getOutputStream(), 403, "Forbidden: Access is denied");
                clientSocket.close();
                return;
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            OutputStream out = clientSocket.getOutputStream();

            String ligne = in.readLine();
            String[] ligneCoupe = ligne.split(" ");

            if (ligneCoupe.length < 3) {
                sendError(out, 400, "Bad Request");
                return;
            }

            String methode = ligneCoupe[0];
            String page = ligneCoupe[1];
            String version = ligneCoupe[2];

            if (methode.equals("GET") && page.equals("/status")) {
                sendPage(out,Status.sendStatus(config));
                return;
            }

            if (page.equals("/")) {
                page = "/index.html";
            }

            System.out.println("Requete de type " + methode + " reçu\nPour acceder à la page " + page + " en version " + version);

            page = page.substring(1);

            File file = new File(config.getRootDir() + "/" + page);
	    System.out.println(file);
            if (!file.exists()) {
                sendError(out, 404, "Not Found");
                return;
            }

            byte[] contenu = Files.readAllBytes(file.toPath());

            if(page.endsWith(".html")) {
                contenu = gererHTML(contenu);
                sendPage(out,contenu);
            }
            else{
                String pagehtml = "";
                String version64 = Base64.getEncoder().encodeToString(contenu);
                if (page.endsWith(".jpg") || page.endsWith(".jpeg")){
                    pagehtml = "<img src=\"data:image/jpeg;base64," + version64 + "\">";
                }  else if (page.endsWith(".gif")) {
                    pagehtml = "<img src=\"data:image/gif;base64," + version64 + "\">";
                } else if (page.endsWith(".png")) {
                    pagehtml = "<img src=\"data:image/png;base64," + version64 + "\">";
                } else if (page.endsWith(".mp3")) {
                    pagehtml = "<audio controls><source type=\"audio/mpeg\" src=\"data:audio/mpeg;base64," + version64 + "\"></audio>";
                } else if (page.endsWith(".wav")) {
                    pagehtml = "<audio controls><source type=\"audio/wav\" src=\"data:audio/wav;base64," + version64 + "\"></audio>";
                } else if (page.endsWith(".mp4")) {
                    pagehtml = "<video controls><source type=\"video/mp4\" src=\"data:video/mp4;base64," + version64 + "\"></video>";
                } else {
                    sendError(out, 415, "Unsupported Media Type");
                    return;
                }
                contenu = pagehtml.getBytes();
                sendPage(out,contenu);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean checkIP(String clientIP) {
        for (String rejectedIP : config.getReject()) {
            if (clientIP.startsWith(rejectedIP)) {
                return false;
            }
        }
        for (String acceptedIP : config.getAccept()) {
            if (clientIP.startsWith(acceptedIP)) {
                return true;
            }
        }
        return config.getAccept().isEmpty();
    }

    private void sendError(OutputStream out, int code, String message) throws IOException {
        String response = "HTTP/1.1 " + code + " " + message + "\r\n\r\n" + message;
        out.write(response.getBytes());
        out.flush();
    }

    private void sendPage(OutputStream out,byte[] contenu ) throws IOException {
        out.write(("HTTP/1.1 200 OK\r\n").getBytes());
        out.write(("Content-Type: text/html\r\n").getBytes());
        out.write(("Content-Length: " + contenu.length + "\r\n").getBytes());
        out.write(("\r\n").getBytes());
        out.write(contenu);
        out.flush();
        System.out.println("Réponse envoyée.");
    }


    private byte[] gererHTML(byte[] contenu)  {
        String contenuString = new String(contenu);
        contenuString = processInterpreteurTags(contenuString);
        return contenuString.getBytes();
    }
    private String processInterpreteurTags(String content) {
        StringBuilder processedContent = new StringBuilder();
        int currentIndex = 0;

        while (currentIndex < content.length()) {
            int startIndex = content.indexOf("<code interpreteur=\"", currentIndex);
            if (startIndex == -1) {
                // Aucune balise <code> avec attribut interpreteur trouvée
                processedContent.append(content.substring(currentIndex));
                break;
            }

            int endIndex = content.indexOf("</code>", startIndex);
            if (endIndex == -1) {
                // Balise de fin </code> manquante, traiter jusqu'à la fin du contenu
                processedContent.append(content.substring(currentIndex));
                break;
            }

            // Ajouter le contenu avant la balise <code>
            processedContent.append(content, currentIndex, startIndex);

            // Extraire l'attribut interpreteur
            int interpreteurStartIndex = startIndex + "<code interpreteur=\"".length();
            int interpreteurEndIndex = content.indexOf("\"", interpreteurStartIndex);
            if (interpreteurEndIndex == -1) {
                // Attribut interpreteur mal formé, sauter cette balise
                processedContent.append(content, startIndex, endIndex + "</code>".length());
            } else {
                String interpreteur = content.substring(interpreteurStartIndex, interpreteurEndIndex);
                String codeToExecute = content.substring(interpreteurEndIndex + 2, endIndex); // +2 pour sauter "> et retour à la ligne

                // Exécuter le code selon l'interpreteur spécifié
                String result = executeCode(interpreteur, codeToExecute.trim());

                // Remplacer la balise <code> par le résultat de l'exécution
                processedContent.append(result);
            }

            currentIndex = endIndex + "</code>".length();
        }

        return processedContent.toString();
    }

    private String executeCode(String interpreteur, String code) {
        StringBuilder output = new StringBuilder();
        try {
            Process process = Runtime.getRuntime().exec(interpreteur);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
            writer.write(code);
            writer.flush();
            writer.close();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            reader.close();

            process.waitFor();
        } catch (IOException | InterruptedException e) {
            output.append("Erreur lors de l'exécution du code : ").append(e.getMessage());
        }
        return output.toString();
    }

}
