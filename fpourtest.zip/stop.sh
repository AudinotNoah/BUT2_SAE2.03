#!/bin/bash

# Lire le PID du fichier pid
if [ -f /var/run/myweb.pid ]; then
    PID=$(cat /var/run/myweb.pid)
    kill $PID
    rm /var/run/myweb.pid
else
    echo "Service not running."
fi
